import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { ArrowLeft, Search, Download, TrendingUp, TrendingDown, Users, CreditCard } from 'lucide-react';
import { Transaction } from '../App';

interface TransactionHistoryProps {
  transactions: Transaction[];
  onBack: () => void;
}

export function TransactionHistory({ transactions, onBack }: TransactionHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date' | 'amount'>('date');

  const filteredTransactions = useMemo(() => {
    let filtered = transactions;

    // Filter by type
    if (filterType !== 'all') {
      filtered = filtered.filter(t => t.type === filterType);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(t =>
        t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.person?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort
    filtered.sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      } else {
        return b.amount - a.amount;
      }
    });

    return filtered;
  }, [transactions, searchTerm, filterType, sortBy]);

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'expense':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      case 'borrow':
        return <TrendingUp className="h-4 w-4 text-orange-500" />;
      case 'lend':
        return <Users className="h-4 w-4 text-blue-500" />;
      case 'emi':
        return <CreditCard className="h-4 w-4 text-purple-500" />;
      default:
        return null;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'expense':
        return 'text-red-600';
      case 'borrow':
        return 'text-orange-600';
      case 'lend':
        return 'text-blue-600';
      case 'emi':
        return 'text-purple-600';
      default:
        return 'text-foreground';
    }
  };

  const totalAmount = filteredTransactions.reduce((sum, t) => sum + t.amount, 0);

  const handleExport = () => {
    // Mock export functionality
    alert('Export functionality would be implemented here');
  };

  return (
    <div className="size-full bg-background overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl">Transaction History</h1>
          </div>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Summary Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl">{transactions.length}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
              <div>
                <p className="text-2xl text-red-600">
                  {transactions.filter(t => t.type === 'expense').length}
                </p>
                <p className="text-sm text-muted-foreground">Expenses</p>
              </div>
              <div>
                <p className="text-2xl text-blue-600">
                  {transactions.filter(t => t.type === 'lend').length}
                </p>
                <p className="text-sm text-muted-foreground">Lent</p>
              </div>
              <div>
                <p className="text-2xl text-orange-600">
                  {transactions.filter(t => t.type === 'borrow').length}
                </p>
                <p className="text-sm text-muted-foreground">Borrowed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="borrow">Borrow</SelectItem>
                  <SelectItem value="lend">Lend</SelectItem>
                  <SelectItem value="emi">EMI</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="amount">Amount</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        {filteredTransactions.length > 0 && (
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>
              Showing {filteredTransactions.length} of {transactions.length} transactions
            </span>
            <span>
              Total: ₹{totalAmount.toLocaleString()}
            </span>
          </div>
        )}

        {/* Transaction List */}
        <Card>
          <CardHeader>
            <CardTitle>Transactions</CardTitle>
            <CardDescription>
              {filterType === 'all' ? 'All your transactions' : `${filterType} transactions`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getTransactionIcon(transaction.type)}
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="capitalize">{transaction.description || transaction.category}</h3>
                        <Badge variant="outline" className="capitalize">
                          {transaction.type}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                        <span>{new Date(transaction.date).toLocaleDateString()}</span>
                        {transaction.category && <span>• {transaction.category}</span>}
                        {transaction.person && <span>• {transaction.person}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg ${getTransactionColor(transaction.type)}`}>
                      {transaction.type === 'lend' ? '+' : '-'}₹{transaction.amount.toLocaleString()}
                    </p>
                    {transaction.status && (
                      <Badge 
                        variant={transaction.status === 'completed' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {transaction.status}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
              {filteredTransactions.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    {searchTerm || filterType !== 'all' 
                      ? 'No transactions match your filters'
                      : 'No transactions yet'
                    }
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}