import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Eye, EyeOff, Mail, Lock, User, Sparkles, Shield, TrendingUp } from 'lucide-react';

interface LoginSignupProps {
  onLogin: (email: string, password: string, name?: string) => void;
}

export function LoginSignup({ onLogin }: LoginSignupProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [signupData, setSignupData] = useState({ name: '', email: '', password: '' });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(loginData.email, loginData.password);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(signupData.email, signupData.password, signupData.name);
  };

  return (
    <div className="size-full relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-slate-900 dark:via-slate-800 dark:to-purple-900">
      {/* Background Design Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-primary rounded-full opacity-10 blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-premium rounded-full opacity-10 blur-3xl"></div>
        <div className="absolute top-1/4 right-1/4 w-32 h-32 bg-gradient-success rounded-full opacity-5 blur-2xl"></div>
      </div>

      <div className="size-full flex flex-col items-center justify-center p-4 relative z-10">
        {/* App Branding */}
        <div className="text-center mb-8 animate-fadeInUp">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-2xl mb-4 shadow-lg">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl text-slate-800 dark:text-white mb-2">
            Welcome to <span className="bg-gradient-primary bg-clip-text text-transparent">SpendWise</span>
          </h1>
          <p className="text-slate-600 dark:text-slate-300">Your smart financial companion</p>
        </div>

        {/* Features Preview */}
        <div className="grid grid-cols-3 gap-4 mb-8 max-w-md animate-slideInRight">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-success rounded-xl flex items-center justify-center mx-auto mb-2 shadow-sm">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">Track Expenses</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-expense rounded-xl flex items-center justify-center mx-auto mb-2 shadow-sm">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">Secure Data</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-premium rounded-xl flex items-center justify-center mx-auto mb-2 shadow-sm">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">Smart Insights</p>
          </div>
        </div>

        {/* Login/Signup Form */}
        <Card className="w-full max-w-md glass backdrop-blur-md border-white/20 shadow-xl animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
          <Tabs defaultValue="login" className="w-full">
            <CardHeader className="text-center pb-4">
              <TabsList className="grid w-full grid-cols-2 bg-slate-100 dark:bg-slate-700">
                <TabsTrigger value="login" className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white">
                  Sign In
                </TabsTrigger>
                <TabsTrigger value="signup" className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white">
                  Sign Up
                </TabsTrigger>
              </TabsList>
            </CardHeader>

            <CardContent className="space-y-4">
              <TabsContent value="login" className="space-y-4 mt-0">
                <div className="text-center mb-4">
                  <CardTitle className="text-xl">Welcome Back!</CardTitle>
                  <CardDescription>Sign in to continue your financial journey</CardDescription>
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="login-email"
                        type="email"
                        placeholder="your@email.com"
                        className="pl-10 bg-white/50 border-slate-200 dark:border-slate-600"
                        value={loginData.email}
                        onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="login-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        className="pl-10 pr-10 bg-white/50 border-slate-200 dark:border-slate-600"
                        value={loginData.password}
                        onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1 h-8 w-8"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-primary border-0 shadow-lg hover:shadow-xl transition-all duration-200"
                    disabled={!loginData.email || !loginData.password}
                  >
                    Sign In
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-4 mt-0">
                <div className="text-center mb-4">
                  <CardTitle className="text-xl">Get Started!</CardTitle>
                  <CardDescription>Create your account and start managing finances</CardDescription>
                </div>

                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-name">Full Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="signup-name"
                        type="text"
                        placeholder="John Doe"
                        className="pl-10 bg-white/50 border-slate-200 dark:border-slate-600"
                        value={signupData.name}
                        onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="your@email.com"
                        className="pl-10 bg-white/50 border-slate-200 dark:border-slate-600"
                        value={signupData.email}
                        onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="signup-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        className="pl-10 pr-10 bg-white/50 border-slate-200 dark:border-slate-600"
                        value={signupData.password}
                        onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1 h-8 w-8"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-success border-0 shadow-lg hover:shadow-xl transition-all duration-200"
                    disabled={!signupData.name || !signupData.email || !signupData.password}
                  >
                    Create Account
                  </Button>
                </form>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-slate-500 dark:text-slate-400 animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
          <p>Secure • Private • Easy to Use</p>
        </div>
      </div>
    </div>
  );
}