import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ArrowLeft, Plus, Calendar, AlertCircle } from 'lucide-react';
import { EMI } from '../App';

interface EMITrackerProps {
  emis: EMI[];
  onSave: (emi: EMI) => void;
  onBack: () => void;
}

export function EMITracker({ emis, onSave, onBack }: EMITrackerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [recurrence, setRecurrence] = useState<'monthly' | 'quarterly' | 'yearly'>('monthly');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newEMI: EMI = {
      id: Date.now().toString(),
      name,
      amount: parseFloat(amount),
      dueDate,
      recurrence,
      status: 'active'
    };

    onSave(newEMI);
    
    // Reset form
    setName('');
    setAmount('');
    setDueDate('');
    setRecurrence('monthly');
    setNotes('');
    setIsAddDialogOpen(false);
  };

  const activeEMIs = emis.filter(emi => emi.status === 'active');
  const completedEMIs = emis.filter(emi => emi.status === 'completed');

  return (
    <div className="size-full bg-background overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl">EMI Tracker</h1>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add EMI
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New EMI</DialogTitle>
                <DialogDescription>Set up a new EMI to track payments</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="emi-name">EMI Name</Label>
                  <Input
                    id="emi-name"
                    placeholder="e.g., Home Loan, Car Loan"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emi-amount">Amount (₹)</Label>
                  <Input
                    id="emi-amount"
                    type="number"
                    step="0.01"
                    placeholder="Enter EMI amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="due-date">Due Date</Label>
                  <Input
                    id="due-date"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recurrence">Recurrence</Label>
                  <Select value={recurrence} onValueChange={(value: any) => setRecurrence(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emi-notes">Notes (Optional)</Label>
                  <Textarea
                    id="emi-notes"
                    placeholder="Additional details"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                  />
                </div>

                <Button type="submit" className="w-full" disabled={!name || !amount || !dueDate}>
                  Save EMI
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Active EMIs</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">{activeEMIs.length}</div>
              <p className="text-xs text-muted-foreground">
                {activeEMIs.length === 1 ? 'EMI' : 'EMIs'} to track
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Monthly Total</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">
                ₹{activeEMIs.reduce((sum, emi) => sum + emi.amount, 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                Total EMI amount
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Due Soon</CardTitle>
              <AlertCircle className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">
                {activeEMIs.filter(emi => {
                  const dueDate = new Date(emi.dueDate);
                  const today = new Date();
                  const diffTime = dueDate.getTime() - today.getTime();
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  return diffDays <= 7;
                }).length}
              </div>
              <p className="text-xs text-muted-foreground">
                Within 7 days
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Active EMIs */}
        <Card>
          <CardHeader>
            <CardTitle>Active EMIs</CardTitle>
            <CardDescription>Your ongoing EMI payments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeEMIs.map((emi) => {
                const dueDate = new Date(emi.dueDate);
                const today = new Date();
                const diffTime = dueDate.getTime() - today.getTime();
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                const isDueSoon = diffDays <= 7;

                return (
                  <div key={emi.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3>{emi.name}</h3>
                        <Badge variant={emi.recurrence === 'monthly' ? 'default' : 'secondary'}>
                          {emi.recurrence}
                        </Badge>
                        {isDueSoon && (
                          <Badge variant="destructive">Due Soon</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Due: {new Date(emi.dueDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg">₹{emi.amount.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">
                        {diffDays > 0 ? `${diffDays} days left` : 'Due today'}
                      </p>
                    </div>
                  </div>
                );
              })}
              {activeEMIs.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No active EMIs</p>
                  <Button variant="outline" className="mt-2" onClick={() => setIsAddDialogOpen(true)}>
                    Add Your First EMI
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Completed EMIs */}
        {completedEMIs.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Completed EMIs</CardTitle>
              <CardDescription>EMIs you've successfully paid off</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {completedEMIs.map((emi) => (
                  <div key={emi.id} className="flex items-center justify-between p-4 border rounded-lg opacity-60">
                    <div>
                      <h3>{emi.name}</h3>
                      <Badge variant="secondary">Completed</Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-lg">₹{emi.amount.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}