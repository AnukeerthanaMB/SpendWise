import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ArrowLeft } from 'lucide-react';
import { Transaction } from '../App';

interface BorrowLendProps {
  onSave: (transaction: Transaction) => void;
  onBack: () => void;
}

export function BorrowLend({ onSave, onBack }: BorrowLendProps) {
  const [amount, setAmount] = useState('');
  const [person, setPerson] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'borrow' | 'lend'>('borrow');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const transaction: Transaction = {
      id: Date.now().toString(),
      type,
      amount: parseFloat(amount),
      person,
      description,
      date,
      status: 'pending'
    };

    onSave(transaction);
  };

  return (
    <div className="size-full bg-background overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b p-4">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl">Borrow / Lend</h1>
        </div>
      </div>

      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle>Track Money Movement</CardTitle>
            <CardDescription>Keep track of money you've borrowed or lent</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={type} onValueChange={(value) => setType(value as 'borrow' | 'lend')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="borrow">I Borrowed</TabsTrigger>
                <TabsTrigger value="lend">I Lent</TabsTrigger>
              </TabsList>
              
              <TabsContent value={type} className="mt-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₹)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      placeholder="Enter amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="person">
                      {type === 'borrow' ? 'Borrowed From' : 'Lent To'}
                    </Label>
                    <Input
                      id="person"
                      type="text"
                      placeholder="Enter person's name"
                      value={person}
                      onChange={(e) => setPerson(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Notes</Label>
                    <Textarea
                      id="description"
                      placeholder="Enter description (optional)"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={!amount || !person}>
                    Save {type === 'borrow' ? 'Borrowed' : 'Lent'} Amount
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-red-600">Money You Owe</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl">₹5,000</div>
              <p className="text-xs text-muted-foreground">To 2 people</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-green-600">Money Owed to You</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl">₹3,500</div>
              <p className="text-xs text-muted-foreground">From 1 person</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}