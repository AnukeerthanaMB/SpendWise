import { serve } from 'https://deno.land/std@0.208.0/http/server.ts'
import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.8'
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS and logging middleware
app.use('*', cors({
  origin: '*',
  credentials: true,
}))
app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Helper function to get user from token
async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return { user: null, error: 'No access token' };
  }
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  return { user, error };
}

// Signup endpoint
app.post('/make-server-f5363e6a/signup', async (c) => {
  try {
    const { name, email, password } = await c.req.json()
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400)
    }

    return c.json({ user: data.user })
  } catch (error) {
    console.log('Signup exception:', error);
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

// Get user profile
app.get('/make-server-f5363e6a/profile', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    // Get user profile from KV store
    const profile = await kv.get(`profile:${user.id}`);
    
    return c.json({ 
      user: {
        id: user.id,
        name: user.user_metadata?.name || '',
        email: user.email,
        ...profile
      }
    })
  } catch (error) {
    console.log('Profile fetch error:', error);
    return c.json({ error: 'Internal server error while fetching profile' }, 500)
  }
})

// Update user profile
app.put('/make-server-f5363e6a/profile', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const profileData = await c.req.json();
    await kv.set(`profile:${user.id}`, profileData);
    
    return c.json({ success: true })
  } catch (error) {
    console.log('Profile update error:', error);
    return c.json({ error: 'Internal server error while updating profile' }, 500)
  }
})

// Get transactions
app.get('/make-server-f5363e6a/transactions', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const transactions = await kv.get(`transactions:${user.id}`) || [];
    return c.json({ transactions })
  } catch (error) {
    console.log('Transactions fetch error:', error);
    return c.json({ error: 'Internal server error while fetching transactions' }, 500)
  }
})

// Add transaction
app.post('/make-server-f5363e6a/transactions', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const transactionData = await c.req.json();
    const transaction = {
      id: Date.now().toString(),
      ...transactionData,
      createdAt: new Date().toISOString()
    };

    const transactions = await kv.get(`transactions:${user.id}`) || [];
    transactions.push(transaction);
    await kv.set(`transactions:${user.id}`, transactions);
    
    return c.json({ transaction })
  } catch (error) {
    console.log('Transaction creation error:', error);
    return c.json({ error: 'Internal server error while creating transaction' }, 500)
  }
})

// Get EMIs
app.get('/make-server-f5363e6a/emis', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const emis = await kv.get(`emis:${user.id}`) || [];
    return c.json({ emis })
  } catch (error) {
    console.log('EMIs fetch error:', error);
    return c.json({ error: 'Internal server error while fetching EMIs' }, 500)
  }
})

// Add EMI
app.post('/make-server-f5363e6a/emis', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const emiData = await c.req.json();
    const emi = {
      id: Date.now().toString(),
      ...emiData,
      status: 'active',
      createdAt: new Date().toISOString()
    };

    const emis = await kv.get(`emis:${user.id}`) || [];
    emis.push(emi);
    await kv.set(`emis:${user.id}`, emis);
    
    return c.json({ emi })
  } catch (error) {
    console.log('EMI creation error:', error);
    return c.json({ error: 'Internal server error while creating EMI' }, 500)
  }
})

// Delete transaction
app.delete('/make-server-f5363e6a/transactions/:id', async (c) => {
  try {
    const { user, error } = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: error || 'Unauthorized' }, 401);
    }

    const transactionId = c.req.param('id');
    const transactions = await kv.get(`transactions:${user.id}`) || [];
    const updatedTransactions = transactions.filter((t: any) => t.id !== transactionId);
    await kv.set(`transactions:${user.id}`, updatedTransactions);
    
    return c.json({ success: true })
  } catch (error) {
    console.log('Transaction deletion error:', error);
    return c.json({ error: 'Internal server error while deleting transaction' }, 500)
  }
})

// Health check
app.get('/make-server-f5363e6a/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

serve(app.fetch)