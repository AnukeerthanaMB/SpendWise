import { useEffect, useState } from 'react';
import { TrendingUp, DollarSign, PieChart, CreditCard, Target, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  // const [loading, setLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);

  const loadingSteps = [
    "Initializing SpendWise...",
    "Loading your financial data...",
    "Setting up dashboard...",
    "Ready to track expenses!"
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      // setLoading(false);
      onComplete();
    }, 3000);

    // Simulate loading steps
    const stepTimer = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % loadingSteps.length);
    }, 600);

    return () => {
      clearTimeout(timer);
      clearInterval(stepTimer);
    };
  }, [onComplete]);

  return (
    <div className="size-full relative overflow-hidden bg-gradient-primary flex items-center justify-center">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Floating Icons */}
        <div className="absolute top-20 left-12 animate-bounce text-white/20">
          <DollarSign size={32} />
        </div>
        <div className="absolute top-32 right-16 animate-pulse text-white/20">
          <PieChart size={28} />
        </div>
        <div className="absolute bottom-32 left-20 animate-bounce text-white/20" style={{ animationDelay: '0.5s' }}>
          <CreditCard size={24} />
        </div>
        <div className="absolute bottom-48 right-12 animate-pulse text-white/20" style={{ animationDelay: '1s' }}>
          <Target size={30} />
        </div>
        <div className="absolute top-1/3 right-1/4 animate-bounce text-white/20" style={{ animationDelay: '1.5s' }}>
          <TrendingUp size={26} />
        </div>
        
        {/* Gradient Orbs */}
        <div className="absolute top-10 right-10 w-32 h-32 bg-gradient-to-br from-white/10 to-white/5 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 left-10 w-24 h-24 bg-gradient-to-br from-white/15 to-white/5 rounded-full blur-xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/3 w-20 h-20 bg-gradient-to-br from-white/10 to-white/5 rounded-full blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center px-8 animate-fadeInUp">
        {/* Logo & App Icon */}
        <div className="mb-8">
          <div className="mx-auto w-24 h-24 bg-white/10 backdrop-blur-md rounded-3xl flex items-center justify-center mb-6 glass">
            <div className="relative">
              <DollarSign size={40} className="text-white" />
              <div className="absolute -top-1 -right-1">
                <Sparkles size={16} className="text-yellow-300 animate-pulse" />
              </div>
            </div>
          </div>
          
          {/* App Name */}
          <h1 className="text-5xl text-white mb-2 tracking-tight">
            Spend<span className="text-yellow-300">Wise</span>
          </h1>
          <p className="text-white/80 text-lg">Smart Money Management</p>
        </div>

        {/* Feature Highlights */}
        <div className="mb-12 space-y-4">
          <div className="flex items-center justify-center space-x-3 text-white/90">
            <TrendingUp size={20} className="text-green-300" />
            <span className="text-sm">Track expenses effortlessly</span>
          </div>
          <div className="flex items-center justify-center space-x-3 text-white/90">
            <PieChart size={20} className="text-blue-300" />
            <span className="text-sm">Visualize spending patterns</span>
          </div>
          <div className="flex items-center justify-center space-x-3 text-white/90">
            <Target size={20} className="text-purple-300" />
            <span className="text-sm">Achieve financial goals</span>
          </div>
        </div>

        {/* Loading Section */}
        <div className="space-y-6">
          {/* Loading Dots */}
          <div className="flex justify-center space-x-2">
            {[0, 1, 2].map((index) => (
              <div
                key={index}
                className="w-3 h-3 bg-white/60 rounded-full animate-pulse"
                style={{ animationDelay: `${index * 0.2}s` }}
              ></div>
            ))}
          </div>
          
          {/* Loading Text */}
          <p className="text-white/70 text-sm animate-pulse">
            {loadingSteps[currentStep]}
          </p>
          
          {/* Progress Bar */}
          <div className="max-w-xs mx-auto">
            <div className="w-full bg-white/20 rounded-full h-1">
              <div className="bg-white h-1 rounded-full transition-all duration-1000" style={{ width: `${((currentStep + 1) / loadingSteps.length) * 100}%` }}></div>
            </div>
          </div>
        </div>

        {/* Version */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <p className="text-white/50 text-xs">Version 1.0.0</p>
        </div>
      </div>

      {/* Animated Wave at Bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-20">
          <path d="M0,60 C150,100 300,0 450,60 C600,120 750,0 900,60 C1050,120 1200,60 1200,60 L1200,120 L0,120 Z" 
                fill="rgba(255,255,255,0.1)" 
                className="animate-pulse">
            <animate attributeName="d" 
                     dur="4s" 
                     repeatCount="indefinite"
                     values="M0,60 C150,100 300,0 450,60 C600,120 750,0 900,60 C1050,120 1200,60 1200,60 L1200,120 L0,120 Z;
                             M0,80 C150,40 300,120 450,80 C600,40 750,120 900,80 C1050,40 1200,80 1200,80 L1200,120 L0,120 Z;
                             M0,60 C150,100 300,0 450,60 C600,120 750,0 900,60 C1050,120 1200,60 1200,60 L1200,120 L0,120 Z"/>
          </path>
        </svg>
      </div>
    </div>
  );
}