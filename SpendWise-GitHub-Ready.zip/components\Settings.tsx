import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { ArrowLeft, User, Bell, Palette, Trash2, Download, LogOut } from 'lucide-react';
import { User as UserType } from '../App';

interface SettingsProps {
  user: UserType | null;
  isDark: boolean;
  onUpdateUser: (userData: Partial<UserType>) => Promise<void>;
  onToggleDark: () => void;
  onLogout: () => void;
  onBack: () => void;
}

export function Settings({ user, isDark, onUpdateUser, onToggleDark, onLogout, onBack }: SettingsProps) {
  const [salary, setSalary] = useState(user?.monthlySalary?.toString() || '');
  const [alertLimit, setAlertLimit] = useState(user?.alertLimit?.toString() || '');
  const [salaryDate, setSalaryDate] = useState(user?.salaryDate?.toString() || '1');
  const [loading, setLoading] = useState(false);

  const handleUpdateSalary = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await onUpdateUser({
        monthlySalary: parseFloat(salary),
        alertLimit: parseFloat(alertLimit),
        salaryDate: parseInt(salaryDate)
      });
      alert('Salary settings updated successfully!');
    } catch (error) {
      alert('Failed to update settings. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetData = () => {
    // In a real app, this would clear all user data
    alert('Data reset functionality would be implemented here');
  };

  const handleExportData = () => {
    // Mock export functionality
    alert('Data export functionality would be implemented here');
  };

  if (!user) return null;

  return (
    <div className="size-full bg-background overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b p-4">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl">Settings</h1>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Profile Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Profile</span>
            </CardTitle>
            <CardDescription>Your account information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white text-xl">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3>{user.name}</h3>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            </div>
            <Button variant="outline" onClick={onLogout} className="w-full">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </CardContent>
        </Card>

        {/* Salary Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Salary Settings</CardTitle>
            <CardDescription>Update your monthly salary and alert preferences</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateSalary} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="settings-salary">Monthly Salary (₹)</Label>
                <Input
                  id="settings-salary"
                  type="number"
                  value={salary}
                  onChange={(e) => setSalary(e.target.value)}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="settings-date">Salary Credit Date</Label>
                <Select value={salaryDate} onValueChange={setSalaryDate} disabled={loading}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 31 }, (_, i) => (
                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                        {i + 1}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="settings-alert">Low Balance Alert Limit (₹)</Label>
                <Input
                  id="settings-alert"
                  type="number"
                  value={alertLimit}
                  onChange={(e) => setAlertLimit(e.target.value)}
                  disabled={loading}
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Updating...' : 'Update Salary Settings'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* App Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Palette className="h-5 w-5" />
              <span>Appearance</span>
            </CardTitle>
            <CardDescription>Customize the app's look and feel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dark-mode">Dark Mode</Label>
                <p className="text-sm text-muted-foreground">Toggle dark/light theme</p>
              </div>
              <Switch
                id="dark-mode"
                checked={isDark}
                onCheckedChange={onToggleDark}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span>Notifications</span>
            </CardTitle>
            <CardDescription>Manage your notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="emi-alerts">EMI Reminders</Label>
                <p className="text-sm text-muted-foreground">Get notified about upcoming EMI payments</p>
              </div>
              <Switch id="emi-alerts" defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="balance-alerts">Balance Alerts</Label>
                <p className="text-sm text-muted-foreground">Get notified when balance is low</p>
              </div>
              <Switch id="balance-alerts" defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="spending-insights">Spending Insights</Label>
                <p className="text-sm text-muted-foreground">Receive weekly spending summaries</p>
              </div>
              <Switch id="spending-insights" defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* Categories Management */}
        <Card>
          <CardHeader>
            <CardTitle>Manage Categories</CardTitle>
            <CardDescription>Customize expense categories</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2">
              {['Food', 'Travel', 'Shopping', 'Entertainment', 'Bills', 'Healthcare'].map((category) => (
                <div key={category} className="flex items-center justify-between p-2 border rounded">
                  <span>{category}</span>
                  <Button variant="ghost" size="sm">Edit</Button>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              Add New Category
            </Button>
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card>
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Export or reset your data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full" onClick={handleExportData}>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="w-full">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Reset All Data
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete all your data including expenses, EMIs, and settings.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleResetData} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Reset Data
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>

        {/* App Info */}
        <Card>
          <CardHeader>
            <CardTitle>About SpendWise</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="w-12 h-12 mx-auto rounded-full bg-green-500 flex items-center justify-center mb-4">
              <span className="text-xl">💰</span>
            </div>
            <p>Version 1.0.0</p>
            <p className="text-sm text-muted-foreground mt-2">
              Track, Save, Succeed
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}