// ... existing code ...
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { User, Transaction, EMI, Screen } from '../App';
import { Plus, TrendingUp, TrendingDown, Calendar, Settings, History, CreditCard, LogOut, Navigation, Wallet, Target, AlertTriangle, DollarSign } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface DashboardProps {
  user: User | null;
  transactions: Transaction[];
  emis: EMI[];
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

export function Dashboard({ user, transactions, emis, onNavigate, onLogout }: DashboardProps) {
  if (!user) return null;

  const currentMonth = new Date().getMonth();
  const monthlyExpenses = transactions
    .filter(t => t.type === 'expense' && new Date(t.date).getMonth() === currentMonth)
    .reduce((sum, t) => sum + t.amount, 0);

  const remainingBalance = (user.monthlySalary || 0) - monthlyExpenses;
  const spendingPercentage = user.monthlySalary ? (monthlyExpenses / user.monthlySalary) * 100 : 0;

  // Expense categories data for pie chart
  const categoryData = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      const category = t.category || 'Other';
      acc[category] = (acc[category] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);

  const pieData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  // Spending trend data for line chart
  const trendData = [
    { month: 'Nov', spent: 25000 },
    { month: 'Dec', spent: 28000 },
    { month: 'Jan', spent: monthlyExpenses },
  ];

  const upcomingEMIs = emis
    .filter(e => e.status === 'active')
    .slice(0, 3);

  const COLORS = ['#10b981', '#f97316', '#3b82f6', '#8b5cf6', '#f59e0b'];

  const getBalanceStatus = () => {
    if (remainingBalance > (user.alertLimit || 0)) {
      return { status: 'good', color: 'text-green-600', bgColor: 'bg-green-50 dark:bg-green-900/20' };
    }
    return { status: 'warning', color: 'text-orange-600', bgColor: 'bg-orange-50 dark:bg-orange-900/20' };
  };

  const balanceStatus = getBalanceStatus();

  return (
    <div className="size-full bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-900 dark:via-slate-800 dark:to-blue-900 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 p-4 z-40">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="animate-fadeInUp">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl text-slate-800 dark:text-white">Welcome back, {user.name}! 👋</h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">Here's your financial overview</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('demo-navigator' as Screen)}
              className="bg-gradient-primary text-white border-0 hover:shadow-lg transition-all duration-200"
            >
              <Navigation className="h-4 w-4 mr-2" />
              All Pages
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-slate-100 dark:hover:bg-slate-800">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-white/95 backdrop-blur-md">
                <DropdownMenuItem onClick={() => onNavigate('settings')}>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onLogout} className="text-red-600 dark:text-red-400">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-7xl mx-auto">
        {/* Balance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-slideInRight">
          <Card className={`${balanceStatus.bgColor} border-0 shadow-lg hover:shadow-xl transition-all duration-200`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm text-slate-700 dark:text-slate-300">Remaining Balance</CardTitle>
              <div className="p-2 bg-white/50 dark:bg-slate-800/50 rounded-lg">
                <Wallet className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl text-slate-800 dark:text-white mb-1">₹{remainingBalance.toLocaleString()}</div>
              <p className={`text-xs ${balanceStatus.color} flex items-center`}>
                {remainingBalance > (user.alertLimit || 0) ? (
                  <>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    You're on track!
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Below alert limit
                  </>
                )}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-0 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm text-slate-700 dark:text-slate-300">Monthly Salary</CardTitle>
              <div className="p-2 bg-white/50 dark:bg-slate-800/50 rounded-lg">
                <Calendar className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl text-slate-800 dark:text-white mb-1">₹{(user.monthlySalary || 0).toLocaleString()}</div>
              <p className="text-xs text-blue-600 dark:text-blue-400">
                Next credit: {user.salaryDate || 1}th of month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 border-0 shadow-lg hover:shadow-xl transition-all duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm text-slate-700 dark:text-slate-300">Spent This Month</CardTitle>
              <div className="p-2 bg-white/50 dark:bg-slate-800/50 rounded-lg">
                <TrendingDown className="h-4 w-4 text-orange-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl text-slate-800 dark:text-white mb-1">₹{monthlyExpenses.toLocaleString()}</div>
              <div className="flex items-center justify-between">
                <p className="text-xs text-orange-600 dark:text-orange-400">
                  {spendingPercentage.toFixed(1)}% of salary
                </p>
                <div className="w-12 bg-orange-200 dark:bg-orange-800 rounded-full h-1">
                  <div 
                    className="bg-gradient-expense h-1 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min(spendingPercentage, 100)}%` }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border-slate-200 dark:border-slate-700 shadow-lg animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Target className="w-5 h-5 mr-2 text-purple-600" />
              Quick Actions
            </CardTitle>
            <CardDescription>Access your most used features instantly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 bg-gradient-success border-0 text-white hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => onNavigate('add-expense')}
              >
                <Plus className="h-6 w-6" />
                <span className="text-xs">Add Expense</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 bg-gradient-expense border-0 text-white hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => onNavigate('borrow-lend')}
              >
                <TrendingUp className="h-6 w-6" />
                <span className="text-xs">Borrow/Lend</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 bg-gradient-premium border-0 text-white hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => onNavigate('emi-tracker')}
              >
                <CreditCard className="h-6 w-6" />
                <span className="text-xs">Add EMI</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex flex-col space-y-2 bg-gradient-primary border-0 text-white hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => onNavigate('transaction-history')}
              >
                <History className="h-6 w-6" />
                <span className="text-xs">History</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
          {/* Expense Categories Pie Chart */}
          <Card className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border-slate-200 dark:border-slate-700 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <div className="w-2 h-2 bg-gradient-primary rounded-full mr-2"></div>
                Expense Categories
              </CardTitle>
              <CardDescription>Your spending breakdown by category</CardDescription>
            </CardHeader>
            <CardContent>
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={60}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex flex-col items-center justify-center h-48 text-slate-400 dark:text-slate-500">
                  <TrendingUp className="h-12 w-12 mb-3" />
                  <p>No expense data yet</p>
                  <p className="text-sm">Start tracking to see insights</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Spending Trend Line Chart */}
          <Card className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border-slate-200 dark:border-slate-700 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <div className="w-2 h-2 bg-gradient-success rounded-full mr-2"></div>
                Spending Trends
              </CardTitle>
              <CardDescription>Monthly spending pattern overview</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={trendData}>
                  <XAxis dataKey="month" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Line 
                    type="monotone" 
                    dataKey="spent" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming EMIs */}
        <Card className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border-slate-200 dark:border-slate-700 shadow-lg animate-fadeInUp" style={{ animationDelay: '0.6s' }}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-red-600" />
              Upcoming EMIs
            </CardTitle>
            <CardDescription>Next due payments to keep track of</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingEMIs.map((emi) => (
                <div key={emi.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-white dark:from-slate-700 dark:to-slate-800 rounded-lg border border-slate-200 dark:border-slate-600 hover:shadow-md transition-all duration-200">
                  <div>
                    <p className="text-slate-800 dark:text-white">{emi.name}</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400 flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      Due: {emi.dueDate}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-slate-800 dark:text-white">₹{emi.amount.toLocaleString()}</p>
                    <span className="inline-flex items-center rounded-full bg-yellow-100 dark:bg-yellow-900/30 px-2.5 py-0.5 text-xs text-yellow-800 dark:text-yellow-300">
                      {emi.status}
                    </span>
                  </div>
                </div>
              ))}
              {upcomingEMIs.length === 0 && (
                <div className="text-center py-8 text-slate-400 dark:text-slate-500">
                  <CreditCard className="h-12 w-12 mx-auto mb-3" />
                  <p>No upcoming EMIs</p>
                  <p className="text-sm">You're all caught up!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}