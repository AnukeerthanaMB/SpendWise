# Deployment Guide - Alternative Free Hosting Platforms

## 🚀 Free Hosting Alternatives to Vercel

### 1. **Netlify** (Recommended)
- **Free Tier**: Unlimited personal projects, 100GB bandwidth/month
- **Features**: Automatic deployments, custom domains, form handling
- **Deployment**: Drag & drop your `dist` folder or connect to Git

**Quick Deploy:**
1. Build your project: `npm run build`
2. Go to [netlify.com](https://netlify.com)
3. Drag & drop the `dist` folder
4. Your app is live instantly!

### 2. **Surge.sh**
- **Free Tier**: Unlimited deployments, custom domains
- **Features**: Simple command-line deployment
- **Deployment**: Install globally and deploy in seconds

**Install & Deploy:**
```bash
npm install -g surge
npm run build
surge dist
```

### 3. **Firebase Hosting**
- **Free Tier**: 10GB storage, 360MB/day bandwidth
- **Features**: Google's hosting, CDN, SSL certificates
- **Deployment**: Install Firebase CLI and deploy

**Install & Deploy:**
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```

### 4. **GitHub Pages**
- **Free Tier**: Unlimited public repositories
- **Features**: Direct from Git, custom domains
- **Deployment**: Enable in repository settings

**Deploy:**
1. Build: `npm run build`
2. Push `dist` folder to `gh-pages` branch
3. Enable GitHub Pages in repository settings

### 5. **Render**
- **Free Tier**: Static sites with automatic deployments
- **Features**: Git integration, custom domains, SSL
- **Deployment**: Connect your Git repository

## 📋 Pre-deployment Checklist

1. ✅ Remove Vercel configuration (already done)
2. ✅ Build your project: `npm run build`
3. ✅ Test locally: `npm run preview`
4. ✅ Check `dist` folder contains all files
5. ✅ Verify environment variables are set

## 🔧 Build Commands

```bash
# Install dependencies
npm install

# Build for production
npm run build

# Preview build locally
npm run preview

# Development server
npm run dev
```

## 🌐 Environment Variables

Make sure to set these in your hosting platform:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## 📁 What Gets Deployed

The `dist` folder contains:
- HTML files
- CSS bundles
- JavaScript bundles
- Assets (images, fonts)
- All optimized for production

## 🚨 Important Notes

- **Supabase**: Your backend will continue working as long as environment variables are set
- **Build Output**: Always deploy the `dist` folder, not the source code
- **Custom Domain**: Most platforms support custom domains for free
- **SSL**: All platforms provide free SSL certificates

## 🆘 Need Help?

- **Netlify**: [docs.netlify.com](https://docs.netlify.com)
- **Surge**: [surge.sh/help](https://surge.sh/help)
- **Firebase**: [firebase.google.com/docs/hosting](https://firebase.google.com/docs/hosting)
- **GitHub Pages**: [pages.github.com](https://pages.github.com)
