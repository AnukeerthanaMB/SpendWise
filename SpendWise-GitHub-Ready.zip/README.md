# 💰 SpendWise - Smart Expense Tracking App

[![React](https://img.shields.io/badge/React-18.2.0-blue.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.3-38B2AC.svg)](https://tailwindcss.com/)
[![Supabase](https://img.shields.io/badge/Supabase-2.39.8-green.svg)](https://supabase.com/)
[![Vite](https://img.shields.io/badge/Vite-4.4.0-yellow.svg)](https://vitejs.dev/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

> **A modern, feature-rich expense tracking application built with React, TypeScript, and Supabase. Track expenses, manage budgets, monitor EMIs, and gain financial insights with a beautiful, responsive interface.**

## ✨ Features

### 📊 **Smart Dashboard**
- **Visual Overview**: Interactive charts and graphs for expense analysis
- **Budget Tracking**: Real-time budget monitoring with alerts
- **Financial Insights**: Spending patterns and trends visualization
- **Quick Actions**: Fast access to common functions

### 💰 **Expense Management**
- **Categorization**: Organize expenses by category (Food, Transport, Shopping, etc.)
- **Date Tracking**: Log expenses with timestamps and due dates
- **Amount Management**: Track both income and expenses
- **Receipt Storage**: Attach and organize receipts

### 🤝 **Borrow & Lend Tracker**
- **Money Owed**: Track money you've borrowed from others
- **Money Lent**: Monitor money you've lent to others
- **Payment Reminders**: Never forget to collect or pay back
- **History**: Complete record of all transactions

### 💳 **EMI Management**
- **Payment Tracking**: Monitor recurring payments and installments
- **Due Date Alerts**: Get notified before payments are due
- **Status Updates**: Track active, completed, and overdue EMIs
- **Amount Calculation**: Automatic EMI amount calculations

### 📈 **Transaction History**
- **Complete Records**: Full history of all financial transactions
- **Search & Filter**: Find specific transactions quickly
- **Export Options**: Download transaction data for analysis
- **Audit Trail**: Track changes and modifications

### ⚙️ **Smart Settings**
- **Salary Configuration**: Set monthly income for budget calculations
- **Alert Thresholds**: Customize spending limit notifications
- **Theme Options**: Light and dark mode support
- **Data Backup**: Export and import your financial data

## 🚀 Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| **React** | 18.2.0 | Frontend framework with hooks |
| **TypeScript** | 5.0 | Type-safe JavaScript development |
| **Tailwind CSS** | 3.3 | Utility-first CSS framework |
| **Supabase** | 2.39.8 | Backend-as-a-Service (Database + Auth) |
| **Vite** | 4.4.0 | Fast build tool and dev server |
| **Radix UI** | Latest | Accessible UI components |
| **Recharts** | 2.8.0 | Beautiful data visualizations |
| **Lucide React** | 0.263.1 | Modern icon library |

## 🎯 Key Features

- **🔐 Secure Authentication**: Supabase-powered user management
- **📱 Responsive Design**: Works perfectly on all devices
- **🌙 Dark Mode**: Eye-friendly dark and light themes
- **⚡ Real-time Updates**: Live data synchronization
- **📊 Data Visualization**: Interactive charts and graphs
- **🔔 Smart Notifications**: Budget alerts and reminders
- **💾 Offline Support**: Works without internet connection
- **🔄 Auto-sync**: Automatic data backup and sync

## 🛠️ Installation & Setup

### Prerequisites
- **Node.js** 18+ 
- **npm** or **yarn**
- **Supabase** account and project

### Quick Start
```bash
# 1. Clone the repository
git clone https://github.com/yourusername/spendwise-app.git
cd spendwise-app

# 2. Install dependencies
npm install

# 3. Set up environment variables
# Create .env.local file with your Supabase credentials

# 4. Start development server
npm run dev

# 5. Build for production
npm run build
```

### Environment Variables
Create a `.env.local` file in the root directory:
```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## 📱 Screenshots

<details>
<summary>📊 Dashboard View</summary>
- Financial overview with charts
- Budget progress tracking
- Quick action buttons
</details>

<details>
<summary>💰 Expense Management</summary>
- Add new expenses
- Category selection
- Amount and date input
</details>

<details>
<summary>📈 Analytics</summary>
- Spending trends
- Category breakdown
- Monthly comparisons
</details>

## 🚀 Deployment

### Free Hosting Options

| Platform | Free Tier | Deployment |
|----------|-----------|------------|
| **Netlify** | Unlimited projects, 100GB/month | Drag & drop `dist` folder |
| **Vercel** | Unlimited projects, 100GB/month | Connect Git repository |
| **Firebase** | 10GB storage, 360MB/day | Firebase CLI deployment |
| **GitHub Pages** | Unlimited public repos | Push to `gh-pages` branch |
| **Surge.sh** | Unlimited deployments | Command line deployment |

**For detailed deployment instructions, see [DEPLOYMENT.md](./DEPLOYMENT.md)**

## 🤝 Contributing

We welcome contributions! Here's how you can help:

1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Commit** your changes (`git commit -m 'Add amazing feature'`)
4. **Push** to the branch (`git push origin feature/amazing-feature`)
5. **Open** a Pull Request

### Development Guidelines
- Follow TypeScript best practices
- Use Tailwind CSS for styling
- Ensure responsive design
- Add proper error handling
- Write meaningful commit messages

## 📊 Project Structure

```
spendwise-app/
├── components/          # React components
│   ├── ui/             # Reusable UI components
│   ├── Dashboard.tsx   # Main dashboard
│   ├── AddExpense.tsx  # Expense form
│   └── ...             # Other components
├── utils/               # Utility functions
│   └── supabase/       # Supabase configuration
├── styles/              # CSS and styling
├── supabase/            # Backend functions
├── dist/                # Production build
└── ...                  # Configuration files
```

## 🔧 Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
npm run type-check   # TypeScript type checking
```

## 🌟 Why Choose SpendWise?

- **🎯 User-Centric Design**: Built with user experience in mind
- **🔒 Privacy First**: Your data stays on your Supabase instance
- **📱 Cross-Platform**: Works on web, mobile, and desktop
- **⚡ Performance**: Fast loading and smooth interactions
- **🔄 Real-time**: Live updates and synchronization
- **🎨 Beautiful UI**: Modern, clean interface design
- **📊 Smart Analytics**: Intelligent financial insights
- **🔔 Smart Alerts**: Proactive budget notifications

## 📈 Roadmap

- [ ] **Mobile App**: React Native version
- [ ] **Multi-Currency**: Support for different currencies
- [ ] **Family Sharing**: Shared expense tracking
- [ ] **AI Insights**: Machine learning for spending patterns
- [ ] **Integration**: Connect with banks and credit cards
- [ ] **Export**: PDF reports and tax documents
- [ ] **Backup**: Cloud backup and restore
- [ ] **API**: Public API for developers

## 🐛 Bug Reports & Feature Requests

- **Bug Reports**: Use the [Issues](https://github.com/yourusername/spendwise-app/issues) tab
- **Feature Requests**: Create a new issue with the "enhancement" label
- **Questions**: Use GitHub Discussions for general questions

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Supabase** for the amazing backend platform
- **Tailwind CSS** for the utility-first CSS framework
- **Radix UI** for accessible component primitives
- **React Team** for the incredible frontend framework
- **Vite** for the lightning-fast build tool

## 📞 Support

- **Documentation**: [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Issues**: [GitHub Issues](https://github.com/yourusername/spendwise-app/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/spendwise-app/discussions)
- **Email**: your-email@example.com

---

<div align="center">

**Made with ❤️ by [Your Name]**

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/yourusername)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/yourusername)
[![Twitter](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/yourusername)

**⭐ Star this repository if it helped you!**

</div>


