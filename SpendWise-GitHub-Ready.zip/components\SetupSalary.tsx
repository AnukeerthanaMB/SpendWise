import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface SetupSalaryProps {
  onComplete: (data: { monthlySalary: number; salaryDate: number; alertLimit: number }) => void;
}

export function SetupSalary({ onComplete }: SetupSalaryProps) {
  const [monthlySalary, setMonthlySalary] = useState('');
  const [salaryDate, setSalaryDate] = useState('1');
  const [alertLimit, setAlertLimit] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({
      monthlySalary: parseFloat(monthlySalary),
      salaryDate: parseInt(salaryDate),
      alertLimit: parseFloat(alertLimit) || parseFloat(monthlySalary) * 0.1
    });
  };

  return (
    <div className="size-full flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-green-50 dark:from-gray-900 dark:to-gray-800">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle>Set Your Monthly Salary</CardTitle>
          <CardDescription>Help us track your finances better</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="salary">Monthly Salary (₹)</Label>
              <Input
                id="salary"
                type="number"
                placeholder="Enter your monthly salary"
                value={monthlySalary}
                onChange={(e) => setMonthlySalary(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="salary-date">Salary Credit Date</Label>
              <Select value={salaryDate} onValueChange={setSalaryDate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select date" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 31 }, (_, i) => (
                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                      {i + 1}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="alert-limit">Low Balance Alert Limit (₹)</Label>
              <Input
                id="alert-limit"
                type="number"
                placeholder="Enter alert limit"
                value={alertLimit}
                onChange={(e) => setAlertLimit(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Leave empty to set 10% of salary as default
              </p>
            </div>
            
            <Button type="submit" className="w-full">
              Save & Continue
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}