import { useState, useEffect } from 'react';
import { supabase, apiCall } from './utils/supabase/client';
import { SplashScreen } from './components/SplashScreen';
import { LoginSignup } from './components/LoginSignup';
import { SetupSalary } from './components/SetupSalary';
import { Dashboard } from './components/Dashboard';
import { AddExpense } from './components/AddExpense';
import { BorrowLend } from './components/BorrowLend';
import { EMITracker } from './components/EMITracker';
import { TransactionHistory } from './components/TransactionHistory';
import { Settings } from './components/Settings';
import { Button } from './components/ui/button';
import { Sparkles, Rocket, Shield, DollarSign, Plus, RefreshCw, CreditCard, FileText, Cog } from 'lucide-react';

export type Screen = 
  | 'splash'
  | 'login'
  | 'setup-salary'
  | 'dashboard'
  | 'add-expense'
  | 'borrow-lend'
  | 'emi-tracker'
  | 'transaction-history'
  | 'settings'
  | 'demo-navigator';

export interface User {
  id: string;
  name: string;
  email: string;
  monthlySalary?: number;
  salaryDate?: number;
  alertLimit?: number;
}

export interface Transaction {
  id: string;
  type: 'expense' | 'borrow' | 'lend' | 'emi';
  amount: number;
  category?: string;
  person?: string;
  description: string;
  date: string;
  status?: 'pending' | 'completed';
  createdAt?: string;
}

export interface EMI {
  id: string;
  name: string;
  amount: number;
  dueDate: string;
  recurrence: 'monthly' | 'quarterly' | 'yearly';
  status: 'active' | 'completed';
  createdAt?: string;
}

// Demo data for testing all screens
const demoUser: User = {
  id: 'demo-1',
  name: 'Demo User',
  email: 'demo@spendwise.com',
  monthlySalary: 50000,
  salaryDate: 1,
  alertLimit: 5000
};

const demoTransactions: Transaction[] = [
  {
    id: '1',
    type: 'expense',
    amount: 500,
    category: 'Food',
    description: 'Lunch at restaurant',
    date: '2025-01-10'
  },
  {
    id: '2',
    type: 'expense',
    amount: 1200,
    category: 'Travel',
    description: 'Bus ticket',
    date: '2025-01-09'
  },
  {
    id: '3',
    type: 'borrow',
    amount: 2000,
    person: 'John',
    description: 'Emergency funds',
    date: '2025-01-08'
  },
  {
    id: '4',
    type: 'lend',
    amount: 1500,
    person: 'Alice',
    description: 'Personal loan',
    date: '2025-01-07'
  }
];

const demoEMIs: EMI[] = [
  {
    id: '1',
    name: 'Home Loan',
    amount: 15000,
    dueDate: '2025-01-15',
    recurrence: 'monthly',
    status: 'active'
  },
  {
    id: '2',
    name: 'Car Loan',
    amount: 8000,
    dueDate: '2025-01-20',
    recurrence: 'monthly',
    status: 'active'
  }
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [user, setUser] = useState<User | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [emis, setEmis] = useState<EMI[]>([]);
  const [isDark, setIsDark] = useState(false);
  const [loading, setLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);

  // Check for existing session on app load
  useEffect(() => {
    checkSession();
  }, []);

  // Apply dark mode
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Load user data when user is set
  useEffect(() => {
    if (user && !demoMode) {
      loadUserData();
    } else if (demoMode) {
      setTransactions(demoTransactions);
      setEmis(demoEMIs);
    }
  }, [user, demoMode]);

  const checkSession = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        // Get user profile from server
        const profileData = await apiCall('/profile');
        setUser(profileData.user);
        setCurrentScreen(profileData.user.monthlySalary ? 'dashboard' : 'setup-salary');
      } else {
        setCurrentScreen('login');
      }
    } catch (error) {
      console.error('Session check error:', error);
      setCurrentScreen('login');
    } finally {
      setLoading(false);
    }
  };

  const loadUserData = async () => {
    try {
      // Load transactions and EMIs
      const [transactionsData, emisData] = await Promise.all([
        apiCall('/transactions'),
        apiCall('/emis')
      ]);

      setTransactions(transactionsData.transactions || []);
      setEmis(emisData.emis || []);
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const handleLogin = async (email: string, password: string, name?: string) => {
    try {
      // let authResult;
      
      if (name) {
        // Signup
        await apiCall('/signup', {
          method: 'POST',
          body: JSON.stringify({ name, email, password })
        });
        
        // Then sign in
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (signInError) throw signInError;
      } else {
        // Login
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (error) throw error;
      }

      // Get user profile
      const profileData = await apiCall('/profile');
      setUser(profileData.user);
      setCurrentScreen(profileData.user.monthlySalary ? 'dashboard' : 'setup-salary');
    } catch (error) {
      console.error('Login error:', error);
      alert((error as any)?.message || 'Login failed. Please try again.');
    }
  };

  const handleSalarySetup = async (salaryData: { monthlySalary: number; salaryDate: number; alertLimit: number }) => {
    try {
      if (demoMode) {
        setUser(prev => prev ? { ...prev, ...salaryData } : null);
        setCurrentScreen('dashboard');
        return;
      }

      await apiCall('/profile', {
        method: 'PUT',
        body: JSON.stringify(salaryData)
      });
      
      setUser(prev => prev ? { ...prev, ...salaryData } : null);
      setCurrentScreen('dashboard');
    } catch (error) {
      console.error('Salary setup error:', error);
      alert('Failed to save salary settings. Please try again.');
    }
  };

  const handleAddTransaction = async (transactionData: Omit<Transaction, 'id' | 'createdAt'>) => {
    try {
      if (demoMode) {
        const newTransaction = {
          ...transactionData,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        };
        setTransactions(prev => [...prev, newTransaction]);
        setCurrentScreen('dashboard');
        return;
      }

      const { transaction } = await apiCall('/transactions', {
        method: 'POST',
        body: JSON.stringify(transactionData)
      });
      
      setTransactions(prev => [...prev, transaction]);
      setCurrentScreen('dashboard');
    } catch (error) {
      console.error('Add transaction error:', error);
      alert('Failed to add transaction. Please try again.');
    }
  };

  const handleAddEMI = async (emiData: Omit<EMI, 'id' | 'status' | 'createdAt'>) => {
    try {
      if (demoMode) {
        const newEMI = {
          ...emiData,
          id: Date.now().toString(),
          status: 'active' as const,
          createdAt: new Date().toISOString()
        };
        setEmis(prev => [...prev, newEMI]);
        setCurrentScreen('dashboard');
        return;
      }

      const { emi } = await apiCall('/emis', {
        method: 'POST',
        body: JSON.stringify(emiData)
      });
      
      setEmis(prev => [...prev, emi]);
      setCurrentScreen('dashboard');
    } catch (error) {
      console.error('Add EMI error:', error);
      alert('Failed to add EMI. Please try again.');
    }
  };

  const handleUpdateUser = async (userData: Partial<User>) => {
    try {
      if (demoMode) {
        setUser(prev => prev ? { ...prev, ...userData } : null);
        return;
      }

      await apiCall('/profile', {
        method: 'PUT',
        body: JSON.stringify(userData)
      });
      
      setUser(prev => prev ? { ...prev, ...userData } : null);
    } catch (error) {
      console.error('Update user error:', error);
      alert('Failed to update profile. Please try again.');
    }
  };

  const handleLogout = async () => {
    try {
      if (demoMode) {
        setDemoMode(false);
        setUser(null);
        setTransactions([]);
        setEmis([]);
        setCurrentScreen('login');
        return;
      }

      await supabase.auth.signOut();
      setUser(null);
      setTransactions([]);
      setEmis([]);
      setCurrentScreen('login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const enterDemoMode = () => {
    setDemoMode(true);
    setUser(demoUser);
    setCurrentScreen('demo-navigator');
  };

  if (loading) {
    return <SplashScreen onComplete={() => {}} />;
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen onComplete={() => setCurrentScreen('login')} />;
      case 'login':
        return (
          <div className="size-full">
            <LoginSignup onLogin={handleLogin} />
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-50">
              <Button 
                onClick={enterDemoMode} 
                className="bg-gradient-premium border-0 text-white shadow-lg hover:shadow-xl transition-all duration-200"
                size="lg"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                🎯 View All 9 Pages (Demo Mode)
              </Button>
            </div>
          </div>
        );
      case 'demo-navigator':
        return (
          <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 via-white to-purple-50 dark:from-slate-900 dark:via-slate-800 dark:to-purple-900 p-4 sm:p-6 lg:p-8">
            {/* Background Elements */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute top-20 right-20 w-32 h-32 bg-gradient-primary rounded-full opacity-10 blur-2xl"></div>
              <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-success rounded-full opacity-10 blur-2xl"></div>
            </div>
            
            <div className="max-w-6xl mx-auto relative z-10">
              <div className="text-center mb-8 animate-fadeInUp">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-2xl mb-4 shadow-lg">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-4xl text-slate-800 dark:text-white mb-2">
                  🎯 Spend<span className="bg-gradient-premium bg-clip-text text-transparent">Wise</span> Demo
                </h1>
                <p className="text-slate-600 dark:text-slate-300 text-lg">Explore all 9 pages of your financial companion</p>
                <div className="mt-6">
                  <Button 
                    onClick={handleLogout} 
                    variant="outline" 
                    size="sm"
                    className="border-slate-300 hover:bg-slate-50 dark:border-slate-600 dark:hover:bg-slate-800"
                  >
                    Exit Demo Mode
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 animate-slideInRight">
                <Button 
                  onClick={() => setCurrentScreen('splash')} 
                  className="h-20 sm:h-24 flex flex-col space-y-2 sm:space-y-3 bg-gradient-primary border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105 p-3 sm:p-4"
                >
                  <Rocket className="w-5 h-5 sm:w-6 sm:h-6" />
                  <span className="text-xs sm:text-sm">1. Splash Screen</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('login')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-success border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <Shield className="w-6 h-6" />
                  <span className="text-sm">2. Login/Signup</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('setup-salary')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-expense border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <DollarSign className="w-6 h-6" />
                  <span className="text-sm">3. Setup Salary</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('dashboard')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-premium border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <div className="w-6 h-6 border-2 border-white rounded grid grid-cols-2 gap-0.5 p-0.5">
                    <div className="bg-white rounded-sm"></div>
                    <div className="bg-white rounded-sm"></div>
                    <div className="bg-white rounded-sm"></div>
                    <div className="bg-white rounded-sm"></div>
                  </div>
                  <span className="text-sm">4. Dashboard</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('add-expense')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-success border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <Plus className="w-6 h-6" />
                  <span className="text-sm">5. Add Expense</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('borrow-lend')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-expense border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <RefreshCw className="w-6 h-6" />
                  <span className="text-sm">6. Borrow/Lend</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('emi-tracker')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-primary border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <CreditCard className="w-6 h-6" />
                  <span className="text-sm">7. EMI Tracker</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('transaction-history')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-premium border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <FileText className="w-6 h-6" />
                  <span className="text-sm">8. Transaction History</span>
                </Button>
                
                <Button 
                  onClick={() => setCurrentScreen('settings')} 
                  className="h-24 flex flex-col space-y-3 bg-gradient-success border-0 text-white hover:shadow-xl transition-all duration-200 hover:scale-105"
                >
                  <Cog className="w-6 h-6" />
                  <span className="text-sm">9. Settings</span>
                </Button>
              </div>
              
              <div className="mt-12 p-6 bg-white/70 dark:bg-slate-800/70 backdrop-blur-md rounded-2xl border border-slate-200 dark:border-slate-700 shadow-lg animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
                <h3 className="text-lg mb-3 text-slate-800 dark:text-white flex items-center">
                  <div className="w-2 h-2 bg-gradient-primary rounded-full mr-3"></div>
                  📱 Complete Navigation Flow
                </h3>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  <span className="inline-flex items-center bg-blue-100 dark:bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-800 dark:text-blue-300 mr-1">Splash</span>
                  → 
                  <span className="inline-flex items-center bg-green-100 dark:bg-green-900/30 px-2 py-1 rounded text-xs text-green-800 dark:text-green-300 mx-1">Login/Signup</span>
                  → 
                  <span className="inline-flex items-center bg-orange-100 dark:bg-orange-900/30 px-2 py-1 rounded text-xs text-orange-800 dark:text-orange-300 mx-1">Setup Salary</span>
                  → 
                  <span className="inline-flex items-center bg-purple-100 dark:bg-purple-900/30 px-2 py-1 rounded text-xs text-purple-800 dark:text-purple-300 mx-1">Dashboard</span>
                  → 
                  <span className="text-xs text-slate-500">All Features</span>
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="inline-flex items-center bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full text-xs text-slate-700 dark:text-slate-300">
                    ✨ Modern Design
                  </span>
                  <span className="inline-flex items-center bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full text-xs text-slate-700 dark:text-slate-300">
                    🔒 Secure Authentication
                  </span>
                  <span className="inline-flex items-center bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full text-xs text-slate-700 dark:text-slate-300">
                    📊 Interactive Charts
                  </span>
                  <span className="inline-flex items-center bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full text-xs text-slate-700 dark:text-slate-300">
                    🌙 Dark Mode
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      case 'setup-salary':
        return <SetupSalary onComplete={handleSalarySetup} />;
      case 'dashboard':
        return <Dashboard 
          user={user}
          transactions={transactions}
          emis={emis}
          onNavigate={setCurrentScreen}
          onLogout={handleLogout}
        />;
      case 'add-expense':
        return <AddExpense 
          onSave={handleAddTransaction}
          onBack={() => setCurrentScreen(demoMode ? 'demo-navigator' : 'dashboard')}
        />;
      case 'borrow-lend':
        return <BorrowLend 
          onSave={handleAddTransaction}
          onBack={() => setCurrentScreen(demoMode ? 'demo-navigator' : 'dashboard')}
        />;
      case 'emi-tracker':
        return <EMITracker 
          emis={emis}
          onSave={handleAddEMI}
          onBack={() => setCurrentScreen(demoMode ? 'demo-navigator' : 'dashboard')}
        />;
      case 'transaction-history':
        return <TransactionHistory 
          transactions={transactions}
          onBack={() => setCurrentScreen(demoMode ? 'demo-navigator' : 'dashboard')}
        />;
      case 'settings':
        return <Settings 
          user={user}
          isDark={isDark}
          onUpdateUser={handleUpdateUser}
          onToggleDark={() => setIsDark(prev => !prev)}
          onLogout={handleLogout}
          onBack={() => setCurrentScreen(demoMode ? 'demo-navigator' : 'dashboard')}
        />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-blue-50 via-white to-indigo-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 overflow-x-hidden">
      {/* Demo Mode Indicator */}
      {demoMode && currentScreen !== 'demo-navigator' && (
        <div className="fixed top-4 right-4 z-50">
          <Button 
            onClick={() => setCurrentScreen('demo-navigator')} 
            size="sm" 
            className="bg-gradient-premium border-0 text-white shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            🎯 Demo Navigator
          </Button>
        </div>
      )}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        {renderScreen()}
      </div>
    </div>
  );
}